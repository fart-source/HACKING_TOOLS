Click on the folder above. Before you right click on a file, single click on it first, or you can
just right click on the name/picture once. Always click yes to run "let them make changes to your
computer."